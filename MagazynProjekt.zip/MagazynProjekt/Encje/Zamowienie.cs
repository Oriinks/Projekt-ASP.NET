﻿using System;

namespace MagazynProjekt.Encje
{
    public class Zamowienie
    {
        public int id { get; set; }
        public string numerzamowienia { get; set; }
        public DateTime data_zamowienia { get; set; }
        public int ilosc { get; set; }
        public virtual Produkt Produkt { get; set; }
        public int? ProduktId { get; set; }
    }
}
