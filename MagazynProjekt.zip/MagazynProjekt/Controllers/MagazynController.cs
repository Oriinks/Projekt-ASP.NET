﻿using AutoMapper;
using MagazynProjekt.Encje;
using MagazynProjekt.Modele;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;

namespace MagazynProjekt.Controllers
{
    [Route("api/zamowienie")]
    public class MagazynController : ControllerBase
    {
        private MagazynContext magazyn;
        private IMapper mapper;
        public MagazynController(MagazynContext magazyn, IMapper mapper)
        {
            this.magazyn = magazyn;
            this.mapper = mapper;
        }
        public ActionResult<List<MagazynDetailsDto>> Get()
        {
            var zamowienia = magazyn.Zamowienia.Include(p => p.Produkt).ToList();
            var zamowieniaDto = mapper.Map<List<MagazynDetailsDto>>(zamowienia);

            return Ok(zamowieniaDto);
        }
        [HttpGet("{name}")]
        public ActionResult<List<MagazynDetailsDto>> Get(string name)
        {
            var zamowienia = magazyn.Zamowienia
                .Include(p => p.Produkt)
                .FirstOrDefault(zamowienie => zamowienie.numerzamowienia.Replace(" ", "-").ToLower() == name.ToLower());

            if (zamowienia == null)
            {
                return NotFound();
            }
            else
            {
                var zamowienieDto = mapper.Map<MagazynDetailsDto>(zamowienia);
                return Ok(zamowienieDto);
            }
        }
    }
}