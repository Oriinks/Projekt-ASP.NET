﻿using Microsoft.EntityFrameworkCore;

namespace MagazynProjekt.Encje
{
    public class MagazynContext : DbContext
    {
        private string polaczenie =
        "Server=(localdb)\\mssqllocaldb;database=Magazyn;Trusted_Connection=True;";
        public DbSet<Produkt> Produkty { get; set; }
        public DbSet<Zamowienie> Zamowienia { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Zamowienie>()
            .HasOne(z => z.Produkt)
            .WithOne(p => p.Zamowienie)
            .HasForeignKey<Zamowienie>(z => z.ProduktId);
        }
        protected override void OnConfiguring(DbContextOptionsBuilder
        optionsBuilder)
        {
            optionsBuilder.UseSqlServer(polaczenie);
        }
    }

}
