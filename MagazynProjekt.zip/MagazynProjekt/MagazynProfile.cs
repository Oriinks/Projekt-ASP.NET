﻿using AutoMapper;
using MagazynProjekt.Encje;
using MagazynProjekt.Modele;

namespace MagazynProjekt
{
    public class MagazynProfile : Profile
    {
        public MagazynProfile()
        {
            CreateMap<Zamowienie, MagazynDetailsDto>()
                .ForMember(n => n.nazwa, map => map.MapFrom(zamowienie => zamowienie.Produkt.nazwa))
                .ForMember(p => p.producent, map => map.MapFrom(zamowienie => zamowienie.Produkt.producent));
        }
    }
}
