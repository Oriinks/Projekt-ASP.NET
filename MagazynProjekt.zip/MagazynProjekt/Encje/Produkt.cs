﻿using System;

namespace MagazynProjekt.Encje
{
    public class Produkt
    {
        public int id { get; set; }
        public string nazwa { get; set; }
        public string producent { get; set; }
        public DateTime wyprodukowano { get; set; }
        public virtual Zamowienie Zamowienie { get; set; }
    }
}
