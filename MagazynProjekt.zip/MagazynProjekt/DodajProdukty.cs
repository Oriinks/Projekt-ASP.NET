﻿using MagazynProjekt.Encje;
using System;
using System.Collections.Generic;
using System.Linq;

namespace MagazynProjekt
{
    public class DodajProdukty
    {
        private MagazynContext magazynContext;
        public DodajProdukty(MagazynContext magazynContext)
        {
            this.magazynContext = magazynContext;
        }
        public void DodajDane()
        {
            if (magazynContext.Database.CanConnect())
            {
                if (!magazynContext.Zamowienia.Any())
                {
                    WstawRekordy();
                }

            }
        }

        private void WstawRekordy()
        {
            var zamowienia = new List<Zamowienie>
            {
                new Zamowienie
                {
                    numerzamowienia = "33333",
                    data_zamowienia = DateTime.Now,
                    ilosc = 456,
                    Produkt = new Produkt
                    {
                        nazwa = "Omen-15",
                        producent = "HP",
                        wyprodukowano = DateTime.Now,
                    },
                },
                new Zamowienie
                {
                    numerzamowienia = "22222",
                    data_zamowienia = DateTime.Now,
                    ilosc = 115,
                    Produkt = new Produkt
                    {
                        nazwa = "Predator",
                        producent = "Acer",
                        wyprodukowano = DateTime.Now,
                    },
                },
                new Zamowienie
                {
                    numerzamowienia = "11111",
                    data_zamowienia = DateTime.Now,
                    ilosc = 36,
                    Produkt = new Produkt
                    {
                        nazwa = "G702",
                        producent = "Asus",
                        wyprodukowano = DateTime.Now,
                    },
                },
                new Zamowienie
                {
                    numerzamowienia = "12345",
                    data_zamowienia = DateTime.Now,
                    ilosc = 50,
                    Produkt = new Produkt
                    {
                        nazwa = "Y700",
                        producent = "Lenovo",
                        wyprodukowano = DateTime.Now,
                    },
                },
                 new Zamowienie
                {
                    numerzamowienia = "23456",
                     data_zamowienia = DateTime.Now,
                    ilosc = 35,
                    Produkt = new Produkt
                    {
                        nazwa = "G72",
                        producent = "MSI",
                        wyprodukowano = DateTime.Now,
                    },
                }
            };
            magazynContext.AddRange(zamowienia);
            magazynContext.SaveChanges();
        }
    }
}
