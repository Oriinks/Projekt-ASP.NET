﻿using System;

namespace MagazynProjekt.Modele
{
    public class MagazynDetailsDto
    {
        public string numerzamowienia { get; set; }
        public DateTime data_zamowienia { get; set; }
        public int ilosc { get; set; }
        public string nazwa { get; set; }
        public string producent { get; set; }
        public DateTime wyprodukowano { get; set; }
    }
}
